import Category from "../../components/Category";
import HeroSlider from "../../components/HeroSection";
const Home=()=>{
    return(

        <>
        <HeroSlider/>
        <Category/>
        </>
    )    
}
export default Home;

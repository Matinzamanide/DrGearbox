import { Link } from "react-router-dom";

const Category = () => {
    const categoryItem = [
        {
            name: "گیربکس صنعتی",
            desc: "انواع موتور گیربکس و گیربکس‌های صنعتی",
            image: "https://shahbazmotor.com/wp-content/uploads/2023/07/industrial-gearbox-category-shahbazmotor.com_-150x150.webp",
            color: "from-orange-500 to-red-500", // تم رنگی اختصاصی
            link:"/گیربکس"
        },
        {
            name: "الکتروموتور",
            desc: "موتورهای الکتریکی تک‌فاز و سه‌فاز",
            image: "https://shahbazmotor.com/wp-content/uploads/2023/07/electric-motor-category-shahbazmotor.com_-150x150.webp",
            color: "from-blue-500 to-cyan-500",
            link:"/الکتروموتور"
        },
        {
            name: "قطعات جانبی",
            desc: "تجهیزات و لوازم یدکی صنعتی",
            image: "https://shahbazmotor.com/wp-content/uploads/2023/07/industrial-accessories-shahbazmotor.com_-150x150.webp",
            color: "from-emerald-500 to-teal-500",
            link:"mahsoolat-janebi"
        },
    ];

    return (
        <section className="w-full max-w-7xl mx-auto my-24 px-4 sm:px-6 lg:px-8 font-sans" dir="rtl">
           
            <div className="text-center mb-16 relative">
                <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">
                    دسته‌بندی محصولات
                </h2>
                <div className="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-cyan-400 mx-auto rounded-full"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10">
                {categoryItem.map((item, index) => (
                    <Link
                    to={item.link}
                        key={index}
                        className="group relative flex flex-col items-center justify-center p-8 rounded-[2.5rem] bg-white border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_20px_40px_rgb(0,0,0,0.12)] transition-all duration-500 cursor-pointer overflow-hidden"
                    >
                        <div className={`absolute inset-0 opacity-0 group-hover:opacity-5 bg-gradient-to-br ${item.color} transition-opacity duration-500`}></div>

                        <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-0 h-1.5 bg-gradient-to-r ${item.color} group-hover:w-full transition-all duration-500 ease-out rounded-b-full`}></div>

                        <div className="relative w-44 h-44 mb-8 transition-transform duration-500 ease-out group-hover:-translate-y-4 group-hover:scale-110 z-10">
                            <div className="absolute inset-0 bg-black/10 blur-2xl rounded-full transform translate-y-8 group-hover:translate-y-12 transition-all duration-500"></div>
                            <img
                                src={item.image}
                                alt={item.name}
                                className="relative w-full h-full object-contain z-10 drop-shadow-md"
                            />
                        </div>

                        <div className="text-center z-10 flex flex-col items-center w-full">
                            <h3 className="text-2xl font-bold text-gray-800 mb-2 group-hover:text-gray-900 transition-colors duration-300">
                                {item.name}
                            </h3>
                            <p className="text-sm text-gray-500 mb-6 opacity-70 group-hover:opacity-100 transition-opacity duration-300">
                                {item.desc}
                            </p>

                            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gray-50 group-hover:bg-white shadow-sm group-hover:shadow-md border border-gray-100 transition-all duration-500 group-hover:w-36 overflow-hidden p-2">
                                <Link to={item.link} className="text-sm font-bold text-gray-800 opacity-0 group-hover:opacity-100 whitespace-nowrap transition-all duration-300 delay-100 translate-x-4 group-hover:translate-x-0 hidden group-hover:block ml-2 ">
                                    مشاهده محصولات
                                </Link>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500 group-hover:text-blue-600 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                                </svg>
                            </div>
                        </div>
                    </Link>
                ))}
            </div>
             
        </section>
    );
};

export default Category;

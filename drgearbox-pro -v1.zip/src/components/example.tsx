
const Example=()=>{
const scrollToSection = (sectionId: string) => {
        const element = document.getElementById(sectionId);
        if (element) {
            element.scrollIntoView({ 
                behavior: "smooth", 
                block: "start" 
            });
        }
    };
    return(
        <div className="">
            <button 
            onClick={()=>scrollToSection("spec")}
            >مشخصات</button>
            <button
             onClick={()=>scrollToSection("fani")}
             >مشخصات فنی</button>
            <button 
            onClick={()=>scrollToSection("general")}
            >اطلاعات عمومی</button>




                    <p>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur, voluptas explicabo voluptatibus quod quos facere fugiat non eos? Neque vel praesentium et. Excepturi veritatis numquam provident, repellendus fugiat perferendis eveniet.
                        Natus laboriosam voluptatum rerum sit impedit eaque quos, et officia temporibus reprehenderit est modi qui ipsa deserunt fugit at harum magnam atque. Cumque, dolores! Rem unde pariatur qui architecto dolore.
                        Perferendis aspernatur eaque, alias, autem ducimus sint mollitia eligendi quae est enim nostrum facilis incidunt, atque nesciunt delectus qui. Obcaecati quae assumenda molestias, maxime veniam labore velit alias earum eos.
                        Voluptatibus totam soluta rerum nihil provident sit sint quis atque quae! Accusantium asperiores atque placeat sunt magnam alias dicta unde corrupti impedit sapiente? Itaque, nostrum est eos a rem earum.
                        Totam, vero iure iste similique neque dolor recusandae dolorum natus fuga velit debitis maiores ratione obcaecati voluptatibus deleniti numquam officia in reiciendis, amet accusamus. Aliquam culpa placeat pariatur iste sapiente!
                        Incidunt, sit ipsum ea, deserunt qui quis porro cumque maxime ab natus optio. Sunt reprehenderit fugiat alias praesentium, officia molestiae aspernatur repudiandae saepe atque voluptate cum iure, laborum deleniti repellendus?
                        Eveniet eum culpa ea velit modi ad aut sapiente, deleniti officia voluptatibus repellendus maxime perspiciatis ipsum quam provident. Assumenda, animi quam ratione dolorum necessitatibus a in culpa? Rem, beatae dolorem.
                        Ducimus obcaecati aperiam illum libero nihil dolorem distinctio, cumque omnis reprehenderit, incidunt aut atque quisquam. Deserunt nisi amet possimus quisquam officia nihil fugiat debitis. Tenetur natus dolorum quae neque fuga.
                        Iste corrupti ipsa et tempore. Iure pariatur voluptatibus, quas molestiae sunt animi est dicta ipsum voluptas deserunt tempore rem eos quaerat amet saepe! Explicabo, officiis. Deserunt optio corporis nesciunt dolorum.
                        Odio ea ad facere quae totam? Minima magnam iste obcaecati, facilis asperiores quod saepe explicabo natus placeat nesciunt illum nostrum corporis exercitationem, qui a doloribus perferendis odit aut alias incidunt.
                        Veritatis adipisci deleniti accusamus excepturi et quos odio, optio enim consectetur eveniet, architecto omnis saepe quasi officia eligendi? Asperiores dolore obcaecati, eveniet animi quia corporis iure! Sit incidunt maiores vel.
                        Eius ad, voluptatum rerum obcaecati, odio dicta praesentium ipsum facere explicabo veritatis, officiis sit amet nam quas autem magnam neque numquam corrupti repellat itaque nemo voluptatibus blanditiis? Eum, rerum minus.
                        Recusandae animi nesciunt eius est facere non fugit eaque quae at nam dolore assumenda, impedit, adipisci quis vero saepe hic eveniet soluta! Iure inventore mollitia molestiae accusamus et soluta maiores?
                        Atque voluptate quos nihil eveniet, reiciendis aliquid doloremque placeat! In quam consectetur, illo delectus cupiditate aperiam neque mollitia quas, maxime iste impedit praesentium excepturi tempore unde ducimus repellendus et nam!
                        Minus nobis quam tenetur tempora possimus quis commodi, iusto voluptas explicabo sapiente! Dolorum quisquam aspernatur soluta ullam nobis, reiciendis culpa quo vel. Consequuntur harum cumque aspernatur quaerat, dignissimos non commodi!
                        Reprehenderit inventore modi nihil. Quod magni eveniet rem minima esse molestiae assumenda, asperiores excepturi culpa? Doloremque quos reprehenderit hic eos at accusantium, quia dolorem dolore repellendus ab temporibus officia. Laborum?
                        Suscipit asperiores quidem possimus totam non eaque itaque eligendi molestias nostrum facere tenetur tempora sit cum doloribus aliquam vel excepturi libero eum, officiis dicta? Iure ea doloribus cupiditate eaque aliquam?
                        Alias magnam temporibus incidunt, maxime delectus beatae? Ipsum sequi eius dolores reprehenderit culpa beatae illo porro facilis minima doloremque doloribus, et possimus iste quidem debitis recusandae consectetur reiciendis vel magnam?
                        Ipsum quod placeat inventore? Earum perferendis nesciunt velit assumenda possimus sed repellat harum non eveniet cupiditate nam ipsam, veritatis quo! Culpa cum necessitatibus doloremque quibusdam eius incidunt temporibus tenetur obcaecati!
                        Alias nobis, exercitationem ipsam et delectus, sunt ipsum ab iure cum similique deleniti id atque asperiores illo! Corrupti cum, quaerat possimus ducimus, debitis error repellendus sint ipsam tenetur aliquid ipsum!
                        Hic sequi culpa commodi? Necessitatibus vel, nesciunt ea odit amet mollitia corrupti laboriosam molestiae debitis fuga, nobis sed impedit. Ut nihil maiores fugiat id esse? Est possimus ipsum aspernatur molestias?
                        Voluptates, cum perferendis. Nobis, veritatis totam nisi reprehenderit ipsum voluptas tempore nesciunt ea repellendus dolores cum explicabo consectetur distinctio placeat minus ducimus. Officiis placeat odit necessitatibus, praesentium sint iure incidunt.
                        A fugiat modi necessitatibus reiciendis accusamus officiis dolor deleniti adipisci consectetur blanditiis molestias, porro vel molestiae. Quibusdam tempora assumenda hic fugiat ab officiis in odio quo. Excepturi autem quis eaque?
                        Ducimus dolores officia rerum neque explicabo, quam beatae et fuga hic maxime odio atque, aspernatur eveniet, inventore fugiat sint? Nihil, temporibus nisi deleniti molestiae blanditiis eveniet? Qui libero itaque officia?
                        Suscipit cum aliquid perferendis porro delectus, provident eum inventore odio quasi labore esse aspernatur nisi quo! Commodi architecto accusamus sapiente numquam, dicta, reiciendis, totam officiis tempore vel soluta minima dolore.
                        Corrupti, odio molestias. Omnis, alias! Soluta quod ipsum cum corrupti. Quo culpa incidunt officia exercitationem, ea deserunt officiis, quaerat natus molestiae debitis quas eveniet quod mollitia ipsam voluptatibus doloribus alias!
                        Vero debitis labore ducimus quos, enim ad ex ipsum sequi odit molestias cupiditate similique assumenda soluta harum hic ab in illum architecto odio laudantium id accusantium dolore. Voluptatibus, aliquam fuga?
                        Iure consequuntur ex officiis atque! Perferendis, nesciunt error in illum laboriosam sit adipisci excepturi ipsa expedita ea tenetur libero hic necessitatibus illo assumenda quibusdam odit saepe iure fuga cumque obcaecati.
                        Explicabo saepe unde perspiciatis nam nulla numquam et sed laudantium dicta commodi minus ea, quas magni perferendis autem porro error, expedita corporis blanditiis, asperiores aspernatur voluptatibus voluptatem? Possimus, dolorem ipsam.
                        Sed illo cupiditate, atque ex, voluptatum beatae reprehenderit harum corporis tempore ab sint, illum autem magnam blanditiis eveniet laborum. Molestiae ipsum error eaque sit quo quis iusto odit, quisquam optio!
                        Quam provident dicta aliquam, voluptas facere reprehenderit eaque illum odit maxime, eum nihil. Voluptates perferendis, consequatur at, laudantium, delectus animi eaque autem sapiente rerum commodi voluptatibus recusandae maxime ut voluptatem.
                        Mollitia nam quasi, voluptatibus quaerat, consequatur ipsum, corporis cumque magnam veritatis exercitationem praesentium iusto. Incidunt, ad mollitia! Odit facilis accusamus, unde at sed ullam in reiciendis iste ipsa dolores possimus!
                        Vitae, quia odit voluptatibus illo magnam molestias, veritatis, quibusdam itaque enim sint placeat doloremque delectus asperiores ut nam dolore. Rem consequuntur hic fuga numquam optio eveniet laudantium labore reprehenderit nulla.
                        Qui dignissimos quas iusto amet doloremque velit, culpa quo iure, facere, suscipit est aliquam ab quisquam ipsam eum a tempore aliquid autem quam optio cupiditate iste atque inventore! Nihil, placeat.
                        Neque ipsam dolores iste distinctio aliquam? Facilis at impedit nostrum dolor veritatis ex natus, sapiente ullam aspernatur autem sed aliquam perferendis magnam corrupti corporis, qui fugiat? Doloribus totam dolore voluptatum?
                        A magni praesentium illo provident recusandae qui magnam blanditiis amet hic dolores fuga voluptatem, possimus, exercitationem non. Quas modi dolor vitae, quisquam ab accusamus adipisci in expedita, unde fugiat explicabo?
                        Perspiciatis maxime assumenda, officiis, facere accusamus provident soluta quidem repellat ipsum molestias quasi! Officia distinctio consectetur libero quisquam ratione at id eos repellat rem quibusdam, earum explicabo nobis dicta dolore.
                        Accusantium necessitatibus quae animi accusamus deleniti, voluptatum perferendis. Esse debitis reiciendis blanditiis alias eligendi veniam recusandae numquam nisi vel eveniet id laudantium odit facere, distinctio accusantium illum eaque ex quisquam!
                        Quia, laborum. Voluptatum, cupiditate rerum. Nihil porro cumque deserunt dignissimos cum dolores eaque totam? Voluptas ullam nisi, soluta facilis vel ex adipisci corrupti atque doloremque, totam quod placeat hic molestias!
                        Veritatis quaerat reprehenderit iure ex voluptas ipsum vel quis dolore tenetur doloribus distinctio natus, iste cum odit recusandae sint pariatur et commodi eum, unde voluptates! Inventore quisquam odio quia debitis.
                        Dolorem error quidem amet! Vitae dicta rem fugit, nihil veniam quisquam quaerat quo natus facilis molestias, laborum accusamus totam vero accusantium, asperiores repellat officiis aut tempore magnam odio quasi excepturi?
                        Eos veniam, accusantium minima accusamus possimus laudantium labore voluptatum eius architecto nihil ab incidunt itaque nam placeat alias saepe quo maiores! Quidem soluta commodi dolorum placeat sit repellat vero voluptates?
                        Impedit sit praesentium ullam tenetur iste iure pariatur temporibus obcaecati explicabo dolorem provident voluptates eveniet molestias ut dolore id, assumenda quia vitae optio? Sint cum vero, voluptatem unde ab delectus?
                        Explicabo animi sed ducimus iusto temporibus, dicta dolorum, quasi illum voluptatum impedit blanditiis eum quisquam cupiditate nihil fugit quidem quia nesciunt recusandae perspiciatis facere a distinctio amet aperiam aliquid. Blanditiis.
                        Natus architecto debitis dolore vel tempore voluptatum doloribus delectus non tempora? Alias quos tempore quae hic ut debitis, rerum molestiae illum, recusandae vitae sed soluta tenetur maiores libero et provident!
                        Id sint vel, excepturi quidem molestiae beatae earum iusto repellat temporibus quia possimus expedita omnis, ducimus molestias, magni pariatur libero reprehenderit minima. Architecto repellat in illo corrupti asperiores ad eligendi.
                        Rerum tempora, minima id nesciunt similique aperiam odit doloribus sed accusantium ut quo impedit earum magnam, cupiditate, maiores doloremque laudantium. Beatae architecto tempore dolores quos? Sint architecto provident asperiores labore!
                        Numquam laborum esse, veritatis cumque error ut dolorum nam, doloribus et, deleniti pariatur voluptatem quam exercitationem corrupti molestias. Sed veniam enim quasi porro animi provident nisi nesciunt facilis tempore perspiciatis.
                        Esse quisquam, sequi ipsum, tempora necessitatibus quia quae mollitia sed ab tenetur ipsa a minus, neque sint. Laborum ullam exercitationem deserunt sunt voluptatem, consequatur ducimus laudantium ea, doloremque, error atque.
                        Placeat, fuga. Minus voluptatibus vel sunt ex doloribus officia officiis quae veritatis, fugit sapiente ut tenetur hic eum praesentium rerum culpa omnis et dicta dolor inventore blanditiis temporibus ratione facilis.
                    </p>






            <div className="">
                <p id="spec">مشخصات</p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore repellendus debitis numquam! Consequuntur facilis facere possimus amet, natus, nobis enim fugit sit nulla nam officiis quia, sint velit recusandae eligendi!
            </div>
            <div id="fani">
                <p id="fani">مشخصات فنی</p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore repellendus debitis numquam! Consequuntur facilis facere possimus amet, natus, nobis enim fugit sit nulla nam officiis quia, sint velit recusandae eligendi!
            </div>
            <div className="" id="general">
                <p>اطلاعات عمومی</p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore repellendus debitis numquam! Consequuntur facilis facere possimus amet, natus, nobis enim fugit sit nulla nam officiis quia, sint velit recusandae eligendi!
            </div>
            
        </div>
    )
}
export default Example;
// src/components/HeroSlider.tsx
import { useKeenSlider } from 'keen-slider/react';
import { useState } from 'react';
import { ChevronLeft, ChevronRight, ArrowLeft } from 'lucide-react';
import 'keen-slider/keen-slider.min.css';

const slides = [
  { 
    id: 1, 
    image: '/drbanner.png', 
    title: 'الکتروموتور موتوژن', 
    subtitle: 'راندمان بالا و مصرف بهینه برای صنایع سنگین',
    badge: 'پرفروش‌ترین',
    link: '/motogen' 
  },
  { 
    id: 2, 
    image: '/drbanner.png', 
    title: 'گیربکس شریف اصفهان', 
    subtitle: 'دوام و قدرت بی‌نظیر در شرایط سخت کاری',
    badge: 'پیشنهاد ویژه',
    link: '/sharif' 
  },
  { 
    id: 3, 
    image: '/drbanner.png', 
    title: 'پمپ پمپیران', 
    subtitle: 'راه‌حل‌های نوین برای انتقال سیالات',
    badge: 'تولید ملی',
    link: '/pumpiran' 
  },
  { 
    id: 4, 
    image: '/drbanner.png', 
    title: 'اینورتر LS', 
    subtitle: 'کنترل هوشمند و دقیق دور موتور',
    badge: 'تکنولوژی روز',
    link: '/ls-inverter' 
  },
];

const HeroSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const [sliderRef, instanceRef] = useKeenSlider(
    {
      loop: true,
      initial: 0,
      slideChanged(slider) {
        setCurrentSlide(slider.track.details.rel);
      },
    },
    [
      // افزونه پخش خودکار (Autoplay)
      (slider) => {
       let timeout: ReturnType<typeof setTimeout>;
let mouseOver = false;

function clearNextTimeout() {
  clearTimeout(timeout);
}

function nextTimeout() {
  clearTimeout(timeout);
  if (mouseOver) return;
  timeout = setTimeout(() => {
    slider.next();
  }, 4000); // تغییر اسلاید هر 4 ثانیه
}

        slider.on("created", () => {
          slider.container.addEventListener("mouseover", () => {
            mouseOver = true;
            clearNextTimeout();
          });
          slider.container.addEventListener("mouseout", () => {
            mouseOver = false;
            nextTimeout();
          });
          nextTimeout();
        });
        slider.on("dragStarted", clearNextTimeout);
        slider.on("animationEnded", nextTimeout);
        slider.on("updated", nextTimeout);
      },
    ]
  );

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="relative group rounded-3xl overflow-hidden shadow-2xl bg-slate-900">
        <div ref={sliderRef} className="keen-slider h-[400px] md:h-[550px]">
          {slides.map((slide) => (
            <div key={slide.id} className="keen-slider__slide relative">
              {/* تصویر پس‌زمینه */}
              <img
                src={slide.image}
                alt={slide.title}
                className="absolute inset-0 w-full h-full object-cover transform scale-105 transition-transform duration-10000 ease-out group-hover:scale-110"
              />
              
              {/* گرادیانت تیره برای خوانایی متن (Overlay) */}
              <div className="absolute inset-0 bg-gradient-to-l from-slate-900/90 via-slate-900/50 to-transparent"></div>

              {/* محتوای متنی روی اسلایدر */}
              <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-20 z-10 w-full md:w-2/3">
                <span className="inline-block px-4 py-1.5 mb-4 text-xs font-bold text-white bg-blue-600/80 backdrop-blur-sm rounded-full w-max border border-blue-400/30">
                  {slide.badge}
                </span>
                <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-4 leading-tight drop-shadow-lg">
                  {slide.title}
                </h2>
                <p className="text-slate-300 text-sm md:text-lg mb-8 max-w-xl drop-shadow-md">
                  {slide.subtitle}
                </p>
                <a 
                  href={slide.link}
                  className="inline-flex items-center justify-center gap-2 bg-white text-slate-900 px-6 py-3 rounded-xl font-bold hover:bg-blue-600 hover:text-white transition-all duration-300 w-max group/btn"
                >
                  مشاهده محصول
                  <ArrowLeft className="w-5 h-5 group-hover/btn:-translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* دکمه‌های ناوبری شیشه‌ای */}
       <button
  onClick={(e) => {
    e.stopPropagation();
    instanceRef.current?.prev();
  }}
  className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/10 backdrop-blur-md hover:bg-white hover:text-slate-900 text-white p-3 rounded-full opacity-0 translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 shadow-lg border border-white/20"
>
  <ChevronLeft className="w-6 h-6" />
</button>

<button
  onClick={(e) => {
    e.stopPropagation();
    instanceRef.current?.next();
  }}
  className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/10 backdrop-blur-md hover:bg-white hover:text-slate-900 text-white p-3 rounded-full opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 shadow-lg border border-white/20"
>
  <ChevronRight className="w-6 h-6" />
</button>


        {/* نقطه‌های ناوبری (Dots) */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-20 bg-slate-900/40 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => instanceRef.current?.moveToIdx(idx)}
              className={`h-2 rounded-full transition-all duration-300 ${
                currentSlide === idx ? 'w-8 bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]' : 'w-2 bg-white/50 hover:bg-white/80'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroSlider;

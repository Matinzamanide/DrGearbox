// App.tsx
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/Home/Home";
import Gearbox from "./pages/Gearbox/Gearbox";
import Layout from "./components/Layout";
import Halazooni from "./pages/Halazooni/Halazooni";
import Helical from "./pages/Helical/Helical";
import Product from "./pages/Product/Product";
import Planetary from "./pages/Planetary/Planetary";
import Jenaghi from "./pages/jenaghi/jenaghi";
import ModelUploader from "./components/ModelUploader";
import AddProduct from "./components/addproduct";
import Example from "./components/example";
import CartIcon from "./components/CartIcon";
import { ShoppingCartProvider } from "./context/ShoppingCartContext";
import CartDrawer from "./pages/Cart/Cart";
import Checkout from "./components/CheckOut";
import Login from "./pages/Auth/Auth";
import UserPanel from "./pages/UserPanel/UserPanel";
import EditProduct from "./components/EditProduct";
import ElectroMotor from "./pages/ElectroMotor/Electromotor";
import Searchedproducts from "./pages/SearchedProducts/SearchedProducts";
import Chini from "./pages/ElectroMotor/Chini/Chini";
import Motogen from "./pages/ElectroMotor/Motogen/Motogen";

function App() {
  return (
    <ShoppingCartProvider>
      <BrowserRouter>
        <CartIcon />        
        <CartDrawer />
        
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/edit/:id" element={<EditProduct />} />
            <Route path="products" element={<Searchedproducts />} />
            <Route path="/auth/login" element={<Login />} />
            <Route path="/userpanel" element={<UserPanel />} />
            <Route path="/cart" element={<Checkout />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/add" element={<AddProduct />} />
            <Route path="/example" element={<Example />} />
            <Route path="/modeluploader" element={<ModelUploader />} />
            <Route path="/product/:id" element={<Product />} />
            <Route path="/گیربکس/گیربکس-حلزونی" element={<Halazooni />} />
            <Route path="/گیربکس/گیربکس-هلیکال" element={<Helical />} />
            <Route path="/گیربکس/گیربکس-خورشیدی" element={<Planetary />} />
            <Route path="/گیربکس/گیربکس-جناغی" element={<Jenaghi />} />
            <Route path="/گیربکس" element={<Gearbox />} />
            <Route path="/الکتروموتور" element={<ElectroMotor />} />
            <Route path="/الکتروموتور/چینی" element={<Chini />} />
            <Route path="/الکتروموتور/موتوژن" element={<Motogen />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </ShoppingCartProvider>
  );
}

export default App;